using System;
using System.Collections.Generic;
using System.Text;

namespace syp.biz.SockJS.NET.Client
{
    public enum StatusCodeEnum
    {
        OPENSERVER,
        CANNOTOPENSERVER,
        SERVERCLOSED,
        SERVERERROR,
        CONNECTED,
        MESSAGE,
        RECEIPT,
        ERROR
    }
}
