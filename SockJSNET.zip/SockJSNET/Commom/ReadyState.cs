namespace syp.biz.SockJS.NET.Common
{
    public enum ReadyState
    {
        CONNECTING = 0,
        OPEN = 1,
        CONNECTED = 2,
        CLOSING = 3,
        CLOSED = 4
    }
}