namespace syp.biz.SockJS.NET.Common.Interfaces
{
    public interface IReceiver : IEventEmitter
    {
        void Abort();
    }
}
